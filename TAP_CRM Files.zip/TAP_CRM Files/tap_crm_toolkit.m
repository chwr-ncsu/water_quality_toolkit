function varargout = tap_crm_toolkit(varargin)
% TAP_CRM_TOOLKIT MATLAB code for tap_crm_toolkit.fig
%      TAP_CRM_TOOLKIT, by itself, creates a new TAP_CRM_TOOLKIT or raises the existing
%      singleton*.
%
%      H = TAP_CRM_TOOLKIT returns the handle to a new TAP_CRM_TOOLKIT or the handle to
%      the existing singleton*.
%
%      TAP_CRM_TOOLKIT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TAP_CRM_TOOLKIT.M with the given input arguments.
%
%      TAP_CRM_TOOLKIT('Property','Value',...) creates a new TAP_CRM_TOOLKIT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tap_crm_toolkit_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tap_crm_toolkit_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tap_crm_toolkit

% Last Modified by GUIDE v2.5 31-Oct-2017 15:24:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tap_crm_toolkit_OpeningFcn, ...
                   'gui_OutputFcn',  @tap_crm_toolkit_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tap_crm_toolkit is made visible.
function tap_crm_toolkit_OpeningFcn(hObject, eventdata, handles, varargin)

  
 handles.directory=pwd;    
    
  handles.FileName_obs='example.xlsx';

  handles.PathName_obs=strcat(handles.directory,'/');
  handles.SheetName_obs='Sheet1';

  
  handles.FileName_obs_csv='example.csv';

  
  handles.PathName_obs_csv=strcat(handles.directory,'/');

  
  handles.log_choice=0;
  handles.box_choice=0;
  
  handles.load_obs_choice=1;
  
  handles.choice1=1;
  handles.choice2=1;
  handles.choice3=1;
  
  
  handles.alpha_lvl=0.05;
  handles.NumSim=100;
  handles.NumSim_wrtds=30;

  handles.corr_data=[];
  handles.nse_data=[];
  handles.ioa_data=[];
    
% Choose default command line output for tap_crm_toolkit
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tap_crm_toolkit wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tap_crm_toolkit_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
% varargout{1} = handles.output;


% --- Executes on button press in radiobutton1.
% --- Use Excel File button
function radiobutton1_Callback(hObject, eventdata, handles)
if get(hObject,'Value')==1;
     handles.load_obs_choice=1;
     set(handles.pushbutton1,'Enable','on');
     set(handles.edit1,'Enable','on');
     set(handles.pushbutton2,'Enable','off');
 end;
    guidata(hObject,handles);


% --- Executes on button press in pushbutton1.
% --- Gets Excel Info : if choose Excel option
function pushbutton1_Callback(hObject, eventdata, handles)
    [FileName_obs_ex,PathName_obs_ex] = uigetfile('*.xlsx','Select the Excel Workbook',handles.directory);
    handles.FileName_obs=FileName_obs_ex;
    handles.PathName_obs=PathName_obs_ex;
    guidata(hObject,handles);
    
    % --- Retrieves Sheet Name for observed data.
    function edit1_Callback(hObject, eventdata, handles)
    SheetName_obs=get(hObject,'String');
    handles.SheetName_obs=SheetName_obs;
    guidata(hObject,handles);
    
    
% --- Executes on button press in radiobutton2.
% --- Use CSV File button
function radiobutton2_Callback(hObject, eventdata, handles)
if get(hObject,'Value')==1;
     handles.load_obs_choice=0;
     set(handles.pushbutton2,'Enable','on');
     set(handles.pushbutton1,'Enable','off');
     set(handles.edit1,'Enable','off');
end;
    guidata(hObject,handles);
   

% --- Executes on button press in pushbutton2.
% --- Gets .CSV Info : if choose CSV
function pushbutton2_Callback(hObject, eventdata, handles)
    [FileName_obs_csv,PathName_obs_csv] = uigetfile('*.csv','Select the Comma Delimited File',handles.directory);
    handles.FileName_obs=FileName_obs_csv;
    handles.PathName_obs=PathName_obs_csv;
    guidata(hObject,handles);
    
 % --- Executes on button press in checkbox1.
 % --- Show log scale
function checkbox1_Callback(hObject, eventdata, handles)
    handles.log_choice=get(hObject,'Value');
    guidata(hObject,handles);  
    
% --- Data Selection Section
% --- Populate Data Table and Plot of Concentration
function pushbutton3_Callback(hObject, eventdata, handles)

    %Reset functions
    clear handles.Data;
    cla(handles.axes1,'reset');
    set(handles.uitable3, 'Data', cell(size(get(handles.uitable3,'Data'))),'ColumnName',[],'RowName',[]);
    
    %Load Observed File from Excel
if handles.load_obs_choice==1;
    [handles.data1 handles.headers1]=xlsread(strcat(handles.PathName_obs,handles.FileName_obs),handles.SheetName_obs);
    handles.Units=handles.headers1(1,5);
    handles.Data=[handles.data1(:,:)];

end;

    %Load Observed File from CVS
if handles.load_obs_choice==0;
    H=readtable(strcat(handles.PathName_obs_csv,handles.FileName_obs_csv));
    handles.data1=H{:,1:5};
    handles.headers1=H.Properties.VariableNames(1:5);
    handles.Units=H.Properties.VariableNames{5};
    handles.Data=[handles.data1(:,:)];
end;
   
    %Removes NaN rows
    handles.data1=handles.data1(~any(isnan(handles.data1),2),:);

    %Populate Time Series Plot and Table
    set(handles.uitable3,'data',handles.Data,'ColumnName',[ handles.headers1(1,1:5)],'RowName',[num2cell(1:1:size(handles.Data(:,1),1))]);
    axes(handles.axes1);
    x=1:1:size(handles.Data(:,1),1);
    if handles.log_choice==1;
        P=plot(x,log(handles.Data(:,5)));
    else;
        P=plot(x,handles.Data(:,5));
    end;    
    set(P(1),'Color','red');
    xlabel('Time (days)');
    xlim([0 size(handles.Data(:,1),1)]);
    ylabel(handles.Units,'Interpreter','none'); 
    legend({'Observed'},'FontSize',8);
    box off;
    guidata(hObject,handles);
    
    % --- Executes on button press in checkbox2.
% --- Pearson's Correlation Checkbox
function checkbox2_Callback(hObject, eventdata, handles)
    if get(hObject,'Value')==1;
        handles.choice1=1;
    end;
    if get(hObject,'Value')==0;
        handles.choice1=0;
    end;
    guidata(hObject,handles);


% --- Executes on button press in checkbox3.
% --- Nash-Sutcliffe Efficiency Checkbox
function checkbox3_Callback(hObject, eventdata, handles)
    if get(hObject,'Value')==1;
        handles.choice2=1;
    end;
    if get(hObject,'Value')==0;
        handles.choice2=0;
    end;
    guidata(hObject,handles);


% --- Executes on button press in checkbox4.
% --- Index of Agreement Checkbox
function checkbox4_Callback(hObject, eventdata, handles)
     if get(hObject,'Value')==1;
        handles.choice3=1;
    end;
    if get(hObject,'Value')==0;
        handles.choice3=0;
    end;
    guidata(hObject,handles);
    
    
    % Gets alpha value
    function edit2_Callback(hObject, eventdata, handles)
    handles.alpha_lvl=str2num(get(hObject,'String'));
    guidata(hObject,handles);
    
    % Gets N value: Number of LOADEST Simulations
function edit3_Callback(hObject, eventdata, handles)
    handles.NumSim=str2num(get(hObject,'String'));
    guidata(hObject,handles); 

    
% --- Executes on button press in pushbutton4.
%RUN LOADEST SIMULATIONS
function pushbutton4_Callback(hObject, eventdata, handles)
    
    eval(['mkdir ''' handles.directory '\'' ''Resamples'';']);

    %Reset plots and tables
    
    cla(handles.axes1,'reset');
    cla(handles.axes2,'reset');
    cla(handles.axes3,'reset');
    cla(handles.axes4,'reset'); 
    
    set(handles.uitable1, 'Data', cell(size(get(handles.uitable3,'Data'))));
    set(handles.uitable3, 'Data', cell(size(get(handles.uitable3,'Data'))),'ColumnName',[],'RowName',[]);
    set(handles.uitable2, 'Data', cell(size(get(handles.uitable3,'Data'))));
    handles.stat=[];
    handles.stat_m=[];
    handles.corr_data=[];
    handles.nse_data=[];
    handles.ioa_data=[];

    %Re-plot time series
    set(handles.uitable3,'data',handles.Data,'ColumnName',[ handles.headers1(1,1:5)],'RowName',[num2cell(1:1:size(handles.Data(:,1),1))]);
    axes(handles.axes1);
    x=1:1:size(handles.Data(:,1),1);
    if handles.log_choice==1;
        P=plot(x,log(handles.Data(:,5)));
    else;
        P=plot(x,handles.Data(:,5));
    end;
    set(P(1),'Color','red');
    xlabel('Time (days)');
    xlim([0 size(handles.Data(:,1),1)]);
    ylabel(handles.Units,'Interpreter','none'); 
    legend({'Observed'},'FontSize',8);
    box off;
    

    
%Define lengths
block_size=1;
l=size(handles.Data(:,5),1);
resamp_times=floor(l/block_size);
resamp_length=resamp_times*block_size;


%handles.NumSim=number of iterations

%Loading Bar
w = waitbar(0,'Running Simulation #: 0','Name','Loading Simulations...Please Wait.','CreateCancelBtn','setappdata(gcf,''canceling'',1)');
setappdata(w,'canceling',0)

for i=0:1:handles.NumSim;
       
    %Exit if Cancel button is pushed
    if getappdata(w,'canceling')
        break
    end
    
    %Update loading bar each simulation
    waitbar(i/handles.NumSim,w,sprintf('Running Simulation #: %i',i));

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    clear est_resamp calib_resamp bootsamp_c bootsamp_l
    
    eval(['mkdir ''' handles.directory '\Resamples\'' ''' num2str(i) ''';']);

    eval(['copyfile ''' handles.directory '\Templates\Conc\calib.inp'' ''' handles.directory '\Resamples\' num2str(i) '\calib.inp'';']);
    eval(['copyfile ''' handles.directory '\Templates\Conc\est.inp'' ''' handles.directory '\Resamples\' num2str(i) '\est.inp'';']);
    eval(['copyfile ''' handles.directory '\Templates\Conc\header.inp'' ''' handles.directory '\Resamples\' num2str(i) '\header.inp'';']);
    eval(['copyfile ''' handles.directory '\Templates\Conc\control.inp'' ''' handles.directory '\Resamples\' num2str(i) '\control.inp'';']);
    eval(['copyfile ''' handles.directory '\Templates\Conc\loadest.exe'' ''' handles.directory '\Resamples\' num2str(i) '\loadest.exe'';']);
 

%%%%%WITH REPLACEMENT%%%%%
    index=[];
    for z=1:1:resamp_times;
                probs=unifrnd(0,1);
                thing=round(1+probs.*(l-1));
                up=floor((block_size-1)/2);
                down=(block_size-1)-up;
                if thing-up <1;
                    index_start=1;
                    index_end=block_size;
                else;
                    if thing+down>l;
                        index_end=l;
                        index_start=l-(block_size-1);
                    else;
                        index_start=thing-up;
                        index_end=thing+down;
                    end;
                end;
                index=[index; (index_start:1:index_end)'];
    end;


    if i==0;
        c_calib_0=handles.Data;
    else;
        eval(['c_calib_' num2str(i) '=[ handles.Data(1:resamp_length,1:3) handles.Data(1:resamp_length,4) handles.Data(index,5)];']);
    end;
      
    if i>0;
        eval(['samp_corr_c(i,1)=corr(c_calib_' num2str(i) '(:,4),c_calib_' num2str(i) '(:,5));']);
    end;
     
    eval(['save(''' handles.directory '\Resamples\' num2str(i) '\c_calib_' num2str(i) '.mat'',''c_calib_' num2str(i) ''');']);

    eval(['array_c=c_calib_' num2str(i) ';']);
    

    for j=1:1:size(array_c ,1);

        if array_c(j,2)< 10;
            month=strcat('0',num2str(array_c(j,2)));
        else;
            month=num2str(array_c(j,2));
        end;

        if array_c(j,3) < 10;
            day=strcat('0',num2str(array_c(j,3)));
        else;
            day=num2str(array_c(j,3));
        end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

         calib_resamp(j,1)=str2num(strcat(num2str(array_c(j,1)),month,day));
         calib_resamp(j,2)=1200;
         calib_resamp(j,3)=0.408735;
         calib_resamp(j,4)=array_c(j,4);
         calib_resamp(j,5)=array_c(j,5);

         est_resamp(j,1)=str2num(strcat(num2str(array_c(j,1)),month,day));
         est_resamp(j,2)=1200;
         est_resamp(j,3)=0.408735;
         est_resamp(j,4)=array_c(j,4);



    end;
    
    eval(['cd ''' handles.directory '\Resamples\' num2str(i) ''';']);

    fid1=fopen('calib.inp','a');
    for m=1:1:size(calib_resamp(:,1),1);
        fseek(fid1,0,'eof');
        fprintf(fid1,'\n');
        fprintf(fid1,'%8.0f\t %4.0f\t %2.5f\t %6.0f\t\t %2.4f',calib_resamp(m,:));
    end;

    fclose(fid1);

    fid2=fopen('est.inp','a');
    for m=1:1:size(est_resamp(:,1),1);
        fseek(fid2,0,'eof');
        fprintf(fid2,'\n');
        fprintf(fid2,'%8.0f\t %4.0f\t %2.6f\t %6.0f\t',est_resamp(m,:));
    end;
    fclose(fid2);
    
    system('.\loadest.exe');   
    
    eval(['c_hat_upload_' num2str(i) ' =dlmread(''nitrogen.ind'',''\'',8);']);
    eval(['c_hat_' num2str(i) '=[c_calib_' num2str(i) '(:,1:4) c_hat_upload_' num2str(i) '(:,4)];']);
    
    eval([' cd ''' handles.directory ''';']);
    
    %Calculate statistics    
    if i>0;
        %Calculate pearson's correlation
        eval(['handles.corr_of_samp(i,1)=corr(c_hat_' num2str(i) '(:,5), c_calib_' num2str(i) '(:,5));']);
        %Using function: nash_sutcliffe( modelled,observed)
        eval(['handles.NSE_of_samp(i,1)=nash_sutcliffe(c_hat_' num2str(i) '(:,5), c_calib_' num2str(i) '(:,5));']);
        %Calculate index of agreement 
        %Using function: index_of_agree(modelled, observed)
        eval(['handles.ioa_of_samp(i,1)=index_of_agree(c_hat_' num2str(i) '(:,5), c_calib_' num2str(i) '(:,5));']);
    end;
    
    clear est_resamp calib_resamp

end;

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%Delete loading bar
delete(w);
set(handles.pushbutton6,'Enable','on');


    set(handles.uitable3,'data',[handles.Data, c_hat_0(:,5)],'ColumnName',[ handles.headers1(1,1:5),'LOADEST'],'RowName',[num2cell(1:1:size(handles.Data(:,1),1))]);
    axes(handles.axes1);
    x=1:1:size(handles.Data(:,1),1);
    if handles.log_choice==1;
        P=plot(x,log(handles.Data(:,5)),x,log(c_hat_0(:,5)));
    else;
        P=plot(x,handles.Data(:,5),x,c_hat_0(:,5));
    end;
    set(P(1),'Color','red');
    set(P(2),'Color','blue');
    xlabel('Time (days)');
    xlim([0 size(handles.Data(:,1),1)]);
    ylabel(handles.Units,'Interpreter','none'); 
    legend({'Observed','LOADEST'},'FontSize',8);
    box off;


%Initilize table row names
handles.result_row_names={'Value';'P-value';'Crit. Value';'SS (%)'};
     

%Populate results group and axes.
k=1;

    %Activated if Pearson's Correlation is chosen
    if handles.choice1==1;
        %Calculate Pearson's Correlation of model to observed
        corr_value=corr(c_hat_0(:,5),c_calib_0(:,5));        
        %Calculate p-value of nonparametric distribution through
        %enumeration
        corr_p_value=sum(handles.corr_of_samp>corr_value)/handles.NumSim;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution
        sorted_corr=sort(handles.corr_of_samp,'descend');
        crit_corr_value=sorted_corr(ceil(handles.NumSim*handles.alpha_lvl),1);
        SS_corr=((corr_value-crit_corr_value)/(1-crit_corr_value))*100;
        
       
        %Plotting nonparametric distribution
        axes(handles.axes3);
        hs1=histfit(handles.corr_of_samp,10,'kernel');
        hold on;
        h_1=scatter(handles.corr_of_samp,repmat(handles.NumSim/100,[1,size(handles.corr_of_samp,1)]));
        delete(hs1(1));
        set(hs1(2),'Color','blue');
        set(hs1(2),'LineWidth',0.5);
        set(h_1,'MarkerEdgeColor','black');
        set(h_1,'Marker','.');
        hold on;
        h2=line([corr_value corr_value], [ylim]);
        h3=line([crit_corr_value crit_corr_value],[ylim]);
        set(h2,'Color','red');
        set(h3,'Color','green');
        xlabel('\rho');
        ylabel('Frequency');
        legend([h2 h3],{'Model Value','Crit. Value'},'FontSize',8);
        box off;
           
        
        %Preparing table
        handles.corr_data{1}=sprintf('%.3f',corr_value);
        handles.corr_data{2}=corr_p_value;
        handles.corr_data{3}=sprintf('%.2f',crit_corr_value);
        handles.corr_data{4}=SS_corr;
        
    else;
        handles.corr_data{1}=[];
        handles.corr_data{2}=[];
        handles.corr_data{3}=[];
        handles.corr_data{4}=[];    
    end;

    %Activated if Nash-Sutcliffe Efficiency is chosen
    if handles.choice2==1;      
                
        %Calculate Nash-Stucliffe Efficiency of model to observed
        nse_value=nash_sutcliffe(c_hat_0(:,5),c_calib_0(:,5));
        %Calculate p-value of nonparametric distribution through
        %enumeration
        nse_p_value=sum(handles.NSE_of_samp>nse_value)/handles.NumSim;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution
        sorted_nse=sort(handles.NSE_of_samp,'descend');
        crit_nse_value=sorted_nse(ceil(handles.NumSim*handles.alpha_lvl),1);
        SS_nse=((nse_value-crit_nse_value)/(1-crit_nse_value))*100;

        
        %Plotting nonparametric distribution
        axes(handles.axes2);
        hs2=histfit(handles.NSE_of_samp,10,'kernel');
        hold on;
        h_2=scatter(handles.NSE_of_samp,repmat(handles.NumSim/100,[1,size(handles.NSE_of_samp,1)]));
        delete(hs2(1));
        set(hs2(2),'Color','blue');
        set(hs2(2),'LineWidth',0.5)
        set(h_2,'MarkerEdgeColor','black');
        set(h_2,'Marker','.');
        hold on;
        h2=line([nse_value nse_value], [ylim]);
        h3=line([crit_nse_value crit_nse_value],[ylim]);
        set(h2,'Color','red');
        set(h3,'Color','green');
        xlabel('NSE');
        ylabel('Frequency');
        legend([h2 h3],{'Model Value','Crit. Value'},'FontSize',8);
        box off;
               
        %Preparing table 
        handles.nse_data{1}=sprintf('%.3f',nse_value);
        handles.nse_data{2}=nse_p_value;
        handles.nse_data{3}=sprintf('%.2f',crit_nse_value);
        handles.nse_data{4}=SS_nse;
        
    else;
        handles.nse_data{1}=[];
        handles.nse_data{2}=[];
        handles.nse_data{3}=[];
        handles.nse_data{4}=[];    
    end;
% 
    %Activated if Index of Agreement is chosen
    if handles.choice3==1;
        %Calculate Index of Agreement of model to observed
        ioa_value=index_of_agree(c_hat_0(:,5),c_calib_0(:,5));       
        %Calculate p-value of nonparametric distribution through
        %enumeration        
        ioa_p_value=sum(handles.ioa_of_samp>ioa_value)/handles.NumSim;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution        
        sorted_ioa=sort(handles.ioa_of_samp,'descend');
        crit_ioa_value=sorted_ioa(ceil(handles.NumSim*handles.alpha_lvl),1);
        SS_ioa=((ioa_value-crit_ioa_value)/(1-crit_ioa_value))*100;

   
        axes(handles.axes4);
        hs3=histfit(handles.ioa_of_samp,10,'kernel');
        hold on;
        h_3=scatter(handles.ioa_of_samp,repmat(handles.NumSim/100,[1,size(handles.ioa_of_samp,1)]));
        delete(hs3(1));
        set(hs3(2),'Color','blue');
        set(hs3(2),'LineWidth',0.5)
        set(h_3,'MarkerEdgeColor','black');
        set(h_3,'Marker','.');
        hold on;
        h2=line([ioa_value ioa_value], [ylim]);
        h3=line([crit_ioa_value crit_ioa_value],[ylim]);
        set(h2,'Color','red');
        set(h3,'Color','green');
        xlabel('IOA');
        ylabel('Frequency');
        legend([h2 h3],{'Model Value','Crit. Value'},'FontSize',8);
        box off;
        
        %Preparing table
        handles.ioa_data{1}=sprintf('%.3f',ioa_value);
        handles.ioa_data{2}=ioa_p_value;
        handles.ioa_data{3}=sprintf('%.2f',crit_ioa_value);
        handles.ioa_data{4}=SS_ioa;
        
    else;
        handles.ioa_data{1}=[];
        handles.ioa_data{2}=[];
        handles.ioa_data{3}=[];
        handles.ioa_data{4}=[];    
    end;
        
        
%,'ColumnFormat',{'char','numeric','numeric'}
set(handles.uitable1,'Data',[handles.result_row_names handles.corr_data' handles.nse_data' handles.ioa_data']);
   
        

        set(handles.checkbox5,'Enable','on');
guidata(hObject,handles);

% --- Executes on button press in checkbox5.
% Choose WRTDS Comparison
function checkbox5_Callback(hObject, eventdata, handles)
    if get(hObject,'Value')==0;
        set(handles.pushbutton5,'Enable','off');
        set(handles.pushbutton6,'Enable','off');
        set(handles.text5,'Enable','off');
        set(handles.text6,'Enable','off');
        set(handles.uitable2,'Enable','off');
        set(handles.edit4,'Enable','off');
        set(handles.edit5,'Enable','off');
    end;
    if get(hObject,'Value')==1;
        set(handles.pushbutton5,'Enable','on');
        set(handles.pushbutton6,'Enable','on');
        set(handles.text5,'Enable','on');
        set(handles.text6,'Enable','on');
        set(handles.uitable2,'Enable','on');
        set(handles.edit4,'Enable','on');
        set(handles.edit5,'Enable','on');        
    end;
    guidata(hObject,handles);


% Get USGS Station Number for WRTDS Code
function edit4_Callback(hObject, eventdata, handles)
    handles.station_name=get(hObject,'String');
    guidata(hObject,handles); 
    
%Get N simulations for WRTDS
    function edit5_Callback(hObject, eventdata, handles)
    handles.NumSim_wrtds=str2num(get(hObject,'String'));
    guidata(hObject,handles);  
    
% --- Executes on button press in pushbutton5.
%MODEL COMPARISON
function pushbutton5_Callback(hObject, eventdata, handles)

    %Re-set tables
    set(handles.uitable2, 'Data', cell(size(get(handles.uitable2,'Data'))));
    clearvars row_names;
    clearvars handles.stat_m;
   
    
        dlmwrite('station_id.csv',handles.station_name,'');
    
    
%Loading bar
w2 = waitbar(0,'Running Simulation #: 0','Name','Loading Simulations...Please Wait.','CreateCancelBtn','setappdata(gcf,''canceling'',1)');
setappdata(w2,'canceling',0)

for i=0:1:handles.NumSim_wrtds;
    

    %Exit if cancel button is pushed
    if getappdata(w2,'canceling')
        break
    end
    
    %Update loading bar each simulation
    waitbar(i/handles.NumSim_wrtds,w2,sprintf('Running Simulation #: %i',i));
    
    eval(['cd ''' handles.directory '\Resamples\' num2str(i) ''';']);

    eval(['load c_calib_' num2str(i) '.mat;']);
    eval(['array=c_calib_' num2str(i) ';']);
    
    if i==0;
        c_hat_upload_0=dlmread('nitrogen.ind','\',8);
        c_hat_0=[c_calib_0(:,1:4) c_hat_upload_0(:,4)];
    end;
    
    eval([' cd ''' handles.directory ''';']);

        dlmwrite('station_data.csv',['Date',',','Remark',',','Value'],'newline','pc','delimiter','');
        for j=1:1:length(array(:,1));
            dlmwrite('station_data.csv',[num2str(array(j,2)),'/',num2str(array(j,3)),'/',num2str(array(j,1)),',,',num2str(array(j,5))],'-append','newline','pc','delimiter','');
        end
    Rpath='C:\Program Files\R\R-3.2.5\bin';
    RscriptFileName=strcat(handles.directory,'\tap_crm_wrtds_model.R');
    RunRcode(RscriptFileName,Rpath);
    
    eval(['c_wrtds_' num2str(i) '=importdata(''conc_estimates.txt'');']);

    %Calculate statistics    
    if i>0;
        %Calculate pearson's correlation
        eval(['handles.corr_of_samp(i,1)=corr(c_wrtds_' num2str(i) '(:,1), c_calib_' num2str(i) '(:,5));']);
        %Using function: nash_sutcliffe( modelled,observed)
        eval(['handles.NSE_of_samp(i,1)=nash_sutcliffe(c_wrtds_' num2str(i) '(:,1), c_calib_' num2str(i) '(:,5));']);
        %Calculate index of agreement 
        %Using function: index_of_agree(modelled, observed)
        eval(['handles.ioa_of_samp(i,1)=index_of_agree(c_wrtds_' num2str(i) '(:,1), c_calib_' num2str(i) '(:,5));']);
    end;

end

%delete loading bar
delete(w2);

    set(handles.uitable3,'data',[handles.Data, c_hat_0(:,5) c_wrtds_0(:,1)],'ColumnName',[ handles.headers1(1,1:5),'LOADEST', 'WRTDS'],'RowName',[num2cell(1:1:size(handles.Data(:,1),1))]);
    axes(handles.axes1);
    x=1:1:size(handles.Data(:,1),1);
    if handles.log_choice==1;
        P=plot(x,log(handles.Data(:,5)),x,log(c_hat_0(:,5)),x,log(c_wrtds_0(:,1)));
    else;
        P=plot(x,handles.Data(:,5),x,c_hat_0(:,5),x,c_wrtds_0(:,1));
    end;
    set(P(1),'Color','red');
    set(P(2),'Color','blue');
    set(P(3),'Color','black');
    xlabel('Time (days)');
    xlim([0 size(handles.Data(:,1),1)]);
    ylabel(handles.Units,'Interpreter','none'); 
    legend({'Observed','LOADEST','WRTDS'},'FontSize',8);
    box off;

%Populate model comparison table 
k=1;
    %Activated if Pearson's Correlation is chosen
    if handles.choice1==1;
        %Calculate Pearson's Correlation of model to observed
        corr_value=corr(c_wrtds_0(:,1),c_calib_0(:,5));        
        %Calculate p-value of nonparametric distribution through
        %enumeration
        corr_p_value=sum(handles.corr_of_samp>corr_value)/handles.NumSim_wrtds;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution
        sorted_corr=sort(handles.corr_of_samp,'descend');
        crit_corr_value=sorted_corr(ceil(handles.NumSim_wrtds*handles.alpha_lvl),1);
        SS_corr=((corr_value-crit_corr_value)/(1-crit_corr_value))*100;
        
        %Populating model comparison table
        row_names{1}='rho';
        row_names{2}='rho p-value';
        row_names{3}='rho crit value';
        row_names{4}='rho SS';
        
        handles.corr_data_m{1}=sprintf('%.3f',corr_value);
        handles.corr_data_m{2}=corr_p_value;
        handles.corr_data_m{3}=sprintf('%.2f',crit_corr_value);
        handles.corr_data_m{4}=SS_corr;
        
      
    else;
        handles.corr_data_m{1}=[];
        handles.corr_data_m{2}=[];
        handles.corr_data_m{3}=[];
        handles.corr_data_m{4}=[];    
    end;
    
    %Activated if Nash-Sutcliffe Efficiency is chosen
    if handles.choice2==1;       
        
        %Calculate Nash-Stucliffe Efficiency of model to observed
        nse_value=nash_sutcliffe(c_wrtds_0(:,1),c_calib_0(:,5));
        %Calculate p-value of nonparametric distribution through
        %enumeration
        nse_p_value=sum(handles.NSE_of_samp>nse_value)/handles.NumSim_wrtds;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution
        sorted_nse=sort(handles.NSE_of_samp,'descend');
        crit_nse_value=sorted_nse(ceil(handles.NumSim_wrtds*handles.alpha_lvl),1);
        SS_nse=((nse_value-crit_nse_value)/(1-crit_nse_value))*100;


        %Populating model comparison table        
        row_names{5}='NSE';
        row_names{6}='NSE p-value';
        row_names{7}='NSE crit value';
        row_names{8}='NSE SS';
        
        handles.nse_data_m{1}=sprintf('%.3f',nse_value);
        handles.nse_data_m{2}=nse_p_value;
        handles.nse_data_m{3}=sprintf('%.2f',crit_nse_value);
        handles.nse_data_m{4}=SS_nse;
        
      
    else;
        handles.nse_data_m{1}=[];
        handles.nse_data_m{2}=[];
        handles.nse_data_m{3}=[];
        handles.nse_data_m{4}=[];    
    end;
    
    %Activated if Index of Agreement is chosen
    if handles.choice3==1;
        %Calculate Index of Agreement of model to observed
        ioa_value=index_of_agree(c_wrtds_0(:,1),c_calib_0(:,5));       
        %Calculate p-value of nonparametric distribution through
        %enumeration        
        ioa_p_value=sum(handles.ioa_of_samp>ioa_value)/handles.NumSim_wrtds;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution
        sorted_ioa=sort(handles.ioa_of_samp,'descend');
        crit_ioa_value=sorted_ioa(ceil(handles.NumSim_wrtds*handles.alpha_lvl),1);
        SS_ioa=((ioa_value-crit_ioa_value)/(1-crit_ioa_value))*100;
   
        
        %Populating model comparison table         
        row_names{9}='IOA';
        row_names{10}='IOA p-value';
        row_names{11}='IOA crit value';
        row_names{12}='IOA SS';
        
        handles.ioa_data_m{1}=sprintf('%.3f',ioa_value);
        handles.ioa_data_m{2}=ioa_p_value;
        handles.ioa_data_m{3}=sprintf('%.2f',crit_ioa_value);
        handles.ioa_data_m{4}=SS_ioa;
        
      
    else;
        handles.ioa_data_m{1}=[];
        handles.ioa_data_m{2}=[];
        handles.ioa_data_m{3}=[];
        handles.ioa_data_m{4}=[];    
    end;
    
    %Calculate model comparison stats: AIC and BIC
        l=length(c_calib_0(:,1));
    
        handles.rss1=sum((c_calib_0(:,5)-c_hat_0(:,5)).^2);
        handles.rss2=sum((c_calib_0(:,5)-c_wrtds_0(:,1)).^2);
    
        row_names{13}='AIC';
    
        aic1=l+(l*log(2*pi))+(l*log(handles.rss1/l))+(2*(+1));
        aic2=l+(l*log(2*pi))+(l*log(handles.rss2/l))+(2*(+1));
        
        handles.aic(1,1)=aic1;
        handles.aic_m(1,1)=aic2;

        row_names{14}='BIC';
        
        bic1=l+(l*log(2*pi))+(l*log(handles.rss1/l))+(log(l)*(4+1));
        bic2=l+(l*log(2*pi))+(l*log(handles.rss2/l))+(log(l)*(5+1));
        
        handles.bic(1,1)=bic1;
        handles.bic_m(1,1)=bic2;
        stat_data_loadest=[handles.corr_data' ; handles.nse_data' ; handles.ioa_data' ; handles.aic ; handles.bic];
        stat_data_wrtds=[handles.corr_data_m' ; handles.nse_data_m' ; handles.ioa_data_m' ; handles.aic_m ; handles.bic_m];

        %,'ColumnFormat',{'char','numeric','numeric'}
        set(handles.uitable2,'Data',[row_names' stat_data_loadest stat_data_wrtds]);
        
guidata(hObject,handles);



% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end






% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
        xlswrite('toolkit_output.xlsx',[get(handles.uitable3,'ColumnName')';num2cell(get(handles.uitable3,'Data'))],'Sheet1');
        xlswrite('toolkit_output.xlsx',[get(handles.uitable1,'ColumnName')';get(handles.uitable1,'Data')],'Sheet2');
        xlswrite('toolkit_output.xlsx',[get(handles.uitable2,'ColumnName')';get(handles.uitable2,'Data')],'Sheet3');


    guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
   
