function [ indexes ] = index_of_agree(model,observed )

top=sum((observed-model).^2);
bottom=sum((abs(observed-mean(observed))+abs(model-mean(model))).^2);


indexes=1-(top/bottom);
end

