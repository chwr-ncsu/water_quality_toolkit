function [ nse ] = nash_sutcliffe( modelled,observed)
%Nash Sutcliffe Efficiency measure


diff=modelled-observed; %start after warmup period
diffmeanflow=observed-(mean(observed)); 
nse= 1-(sum(diff.^2))/(sum(diffmeanflow.^2));

end
