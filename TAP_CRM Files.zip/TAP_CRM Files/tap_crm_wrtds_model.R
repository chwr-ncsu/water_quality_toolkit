#####WRTDS EGRET Modelling#####
##January 25, 2016##

###############################Packages and Libraries#####################
install.packages(c("dataRetrieval","EGRET"),repos="http://cran.rstudio.com/")
install.packages("hydroGOF",repos="http://cran.rstudio.com/")
install.packages("xlsx",repos="http://cran.rstudio.com/")
install.packages("rJava",repos="http://cran.rstudio.com/")
install.packages("xlsxjars",repos="http://cran.rstudio.com/")


library(dataRetrieval)
library(EGRET)
library(rJava)
library(xlsx)
library(Metrics)
library(hydroGOF)

########################################################################
setwd("C:/Program Files/TAP_CRM/application")
#####################Clear Workspace to Start#########################
rm(list=ls())

siteNumber=toString(read.table(file="./station_id.csv",sep='',colClasses='character'))
nutrient_file_name<-'station_data.csv'

nutrient_file_path<-getwd()

#################Read in Information#############################
Sample<-readUserSample(nutrient_file_path,nutrient_file_name)

QParameterCd <-"00060"
StartDate <- Sample$Date[1]
EndDate<- Sample$Date[length(Sample$Date)]

Daily <-readNWISDaily(siteNumber,QParameterCd,StartDate,EndDate)

#Total nitrogen, water, unfiltered, mg/L
ParameterCd<-"00600"

INFO<-readNWISInfo(siteNumber,ParameterCd,interactive = FALSE)
#NOW ENTER RESPONSES IN CONSOLE:
#carriage return, TAR, carraige return, 

Sample<-readUserSample(nutrient_file_path,nutrient_file_name)

Sample<-removeDuplicates(Sample)

#####Model Calculations#####
eList <- mergeReport(INFO,Daily,Sample)
# eList <- modelEstimation(eList, windowY = 7, windowQ = 2, windowS = 0.5, minNumObs= 50, minNumUncen =30, edgeAdjust = TRUE)
eList<-modelEstimation(eList, minNumObs=10)

y<-eList$Sample$ConcAve
yhat<-eList$Sample$ConcHat

write.table(yhat,file="conc_estimates.txt",row.names=FALSE,col.names=FALSE)

