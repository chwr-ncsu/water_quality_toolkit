function varargout = tap_wq_toolkit(varargin)
% TAP_WQ_TOOLKIT MATLAB code for tap_wq_toolkit.fig
%      TAP_WQ_TOOLKIT, by itself, creates a new TAP_WQ_TOOLKIT or raises the existing
%      singleton*.
%
%      H = TAP_WQ_TOOLKIT returns the handle to a new TAP_WQ_TOOLKIT or the handle to
%      the existing singleton*.
%
%      TAP_WQ_TOOLKIT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TAP_WQ_TOOLKIT.M with the given input arguments.
%
%      TAP_WQ_TOOLKIT('Property','Value',...) creates a new TAP_WQ_TOOLKIT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tap_wq_toolkit_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tap_wq_toolkit_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tap_wq_toolkit

% Last Modified by GUIDE v2.5 21-Mar-2017 22:18:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tap_wq_toolkit_OpeningFcn, ...
                   'gui_OutputFcn',  @tap_wq_toolkit_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tap_wq_toolkit is made visible.
function tap_wq_toolkit_OpeningFcn(hObject, eventdata, handles, varargin)
  handles.FileName_obs='example.xlsx';
  handles.FileName_mod='example.xlsx';
  handles.FileName_comp='example.xlsx';
  handles.PathName_obs=strcat(pwd,'/');
  handles.PathName_mod=strcat(pwd,'/');
  handles.PathName_comp=strcat(pwd,'/');
  handles.SheetName_obs='Sheet1';
  handles.SheetName_mod='Sheet2';
  handles.SheetName_comp='Sheet3';
  handles.FileName_obs_csv='ex_obs.csv';
  handles.FileName_mod_csv='ex_mod.csv'
  handles.FileName_comp_csv='ex_comp.csv';
  handles.PathName_obs_csv=strcat(pwd,'/');
  handles.PathName_mod_csv=strcat(pwd,'/');
  handles.PathName_comp_csv=strcat(pwd,'/');
  handles.log_choice=0;
  handles.box_choice=0;
  handles.load_obs_choice=1;
  handles.load_mod_choice=1;
  handles.load_comp_choice=1;
  handles.choice1=1;
  handles.choice2=1;
  handles.choice3=1;
  handles.comp_choice=0;
  handles.alpha_lvl=0.05;
  handles.NumSim=1000;
  handles.lambda=0.5;
  handles.mod1_parm_num=3;
  handles.mod2_parm_num=3;
  handles.corr_data=[];
  handles.nse_data=[];
  handles.ioa_data=[];
    
    
    handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

%UIWAIT makes tap_wq_toolkit wait for user response (see UIRESUME)
% uiwait(handles.figure1);




% --- Outputs from this function are returned to the command line.
function varargout = tap_wq_toolkit_OutputFcn(~, eventdata, handles) 

%  varargout{1} = handles.output;



function edit6_Callback(hObject, eventdata, handles)
    handles.alpha_lvl=str2num(get(hObject,'String'));
    guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Data Selection Section
function pushbutton7_Callback(hObject, eventdata, handles)
    %Reset functions
    clear handles.Data;
    cla(handles.axes6,'reset');
    set(handles.uitable2, 'Data', cell(size(get(handles.uitable2,'Data'))),'ColumnName',[],'RowName',[]);
    
    %Load Observed File from Excel
if handles.load_obs_choice==1;
    [handles.data1 handles.headers1]=xlsread(strcat(handles.PathName_obs,handles.FileName_obs),handles.SheetName_obs);
    handles.Units=handles.headers1(1,5);
end;
    %Load Model 1 File from Excel
if handles.load_mod_choice==1;
    [handles.data2 handles.headers2]=xlsread(strcat(handles.PathName_mod,handles.FileName_mod),handles.SheetName_mod);
end;
    %Load Observed File from CVS
if handles.load_obs_choice==0;
    H=readtable(strcat(handles.PathName_obs_csv,handles.FileName_obs_csv));
    handles.data1=H{:,1:4};
    handles.headers1=H.Properties.VariableNames(1:4);
    handles.Units=H.Properties.VariableNames{5};
end;
    %Load Model 1 File from CVS
if handles.load_mod_choice==0;
    H=readtable(strcat(handles.PathName_mod_csv,handles.FileName_mod_csv));
    handles.data2=H{:,1:4};
    handles.headers2=H.Properties.VariableNames(1:4);
end;
    
    
    
    %Removes NaN rows
    handles.data1=handles.data1(~any(isnan(handles.data1),2),:);
    handles.data2=handles.data2(~any(isnan(handles.data2),2),:);
    
    %Match data sets 
    [C,iA,iB]=intersect(handles.data1(:,1:3),handles.data2(:,1:3),'rows');
    
    %Log Transformation
if handles.log_choice==1;
    handles.Data=[handles.data1(iA,1:3) log(handles.data1(iA,4)) log(handles.data2(iB,4))];
end;
    
    %BoxCox Transformation
if handles.box_choice==1;
   [transdat1]=boxcox(handles.data1(iA,4));
   [transdat2]=boxcox(handles.data2(iB,4));
   handles.Data=[handles.data1(iA,1:3) transdat1 transdat2];
end;

    %No Transform
if handles.log_choice==0 & handles.box_choice==0;
    handles.Data=[handles.data1(iA,1:3) handles.data1(iA,4) handles.data2(iB,4)];
end;
    
    %Populate Time Series Plot and Table
    set(handles.uitable2,'data',handles.Data,'ColumnName',[ handles.headers1(1,1:4) handles.headers2(1,4)],'RowName',[num2cell(1:1:size(handles.Data(:,1),1))]);
    axes(handles.axes6);
    x=1:1:size(handles.Data(:,1),1);
    P=plot(x,handles.Data(:,4),x,handles.Data(:,5));
    set(P(1),'Color','red');
    set(P(2),'Color','black');
    xlabel('Time (days)');
    xlim([0 size(handles.Data(:,1),1)]);
    ylabel(handles.Units,'Interpreter','none'); 
    legend([handles.headers1(1,4) handles.headers2(1,4)],'FontSize',8);
    box off;
    guidata(hObject,handles);

% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)

    %Reset plots and tables
    
    cla(handles.axes6,'reset');
    cla(handles.axes5,'reset');
    cla(handles.axes7,'reset');
    cla(handles.axes8,'reset');
    set(handles.text17,'Visible','Off');
    set(handles.text18,'Visible','Off');
    set(handles.text16,'Visible','Off');
    set(handles.uitable3, 'Data', cell(size(get(handles.uitable3,'Data'))),'ColumnName',[],'RowName',[]);
    set(handles.uitable2, 'Data', cell(size(get(handles.uitable3,'Data'))),'ColumnName',[],'RowName',[]);
    set(handles.uitable4, 'Data', cell(size(get(handles.uitable3,'Data'))));
    handles.stat=[];
    handles.stat_m=[];
    handles.corr_data=[];
    handles.nse_data=[]
    handles.ioa_data=[];

    %Re-plot time series
    set(handles.uitable2,'data',handles.Data,'ColumnName',[ handles.headers1(1,1:4) handles.headers2(1,4)],'RowName',[num2cell(1:1:size(handles.Data(:,1),1))]);
    axes(handles.axes6);
    x=1:1:size(handles.Data(:,1),1);
    P=plot(x,handles.Data(:,4),x,handles.Data(:,5));
    set(P(1),'Color','red');
    set(P(2),'Color','black');
    xlabel('Time (days)');
    xlim([0 size(handles.Data(:,1),1)]);
    ylabel(handles.Units,'Interpreter','none'); 
    legend([handles.headers1(1,4) handles.headers2(1,4)],'FontSize',8);
    box off;
    

%Define length
l=size(handles.Data(:,4),1);


%handles.NumSim=number of iterations

%Loading Bar
w = waitbar(0,'Running Simulation #: 0','Name','Loading Simulations...Please Wait.','CreateCancelBtn','setappdata(gcf,''canceling'',1)');
setappdata(w,'canceling',0)

for i=1:1:handles.NumSim;
    
%Method: Assign uniform probability for each entry of model length "l", then convert to
%an index ranging from 1 to "l", rounding allows for with replacement.
%Resample from Model 2, NumSim times creating vectors of length "l".
    
    %Exit if Cancel button is pushed
    if getappdata(w,'canceling')
        break
    end
    
    %Update loading bar each simulation
    waitbar(i/handles.NumSim,w,sprintf('Running Simulation #: %i',i));
    
        %Bootstrap Sample
        boots=unifrnd(0,1,[l 1]);
        I=round(1+boots.*(l-1));
        bootsamp(:,1)=handles.Data(I,5);


    %Calculate statistics    
    %Caclulate mean
    handles.mean_of_samp(i,1)=mean(bootsamp(:,1));
    %Calculate pearson's correlation
    handles.corr_of_samp(i,1)=corr(bootsamp(:,1),handles.Data(1:1:l,4));
    %Calculate nash-sutcliffe efficiency
    %Using function: nash_sutcliffe( modelled,observed)
    handles.NSE_of_samp(i,1)=nash_sutcliffe(bootsamp(:,1),handles.Data(1:1:l,4)); 
    %Calculate nash-sutcliffe efficiency in log space
    %Using function: log_nash_sutcliffe( modelled,observed)  
    handles.NSE_log_of_samp(i,1)=log_nash_sutcliffe(bootsamp(:,1),handles.Data(1:1:l,4));
    %Calculate index of agreement 
    %Using function: index_of_agree(modelled, observed)
    handles.ioa_of_samp(i,1)=index_of_agree(bootsamp(:,1),handles.Data(1:1:l,4));
     

end

%Delete loading bar
delete(w);
set(handles.pushbutton16,'Enable','on');

%Initilize table row names
handles.result_row_names={'Value';'P-value';'Crit. Values';'SS (%)'};

     

%Populate results group and axes.
k=1;

    %Activated if Pearson's Correlation is chosen
    if handles.choice1==1;
        %Calculate Pearson's Correlation of model to observed
        handles.stat(k,1)=corr(handles.Data(:,5),handles.Data(:,4));        
        %Calculate p-value of nonparametric distribution through
        %enumeration
        corr_diff=abs(mean(handles.corr_of_samp)-handles.stat(k,1));
        corr_p_value=(sum(handles.corr_of_samp<(mean(handles.corr_of_samp)-corr_diff))+sum(handles.corr_of_samp>(mean(handles.corr_of_samp)+corr_diff)))/handles.NumSim;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution
        sorted_corr=sort(handles.corr_of_samp);
        index_corr_1=ceil(handles.NumSim*(handles.alpha_lvl/2));
        index_corr_2=ceil(handles.NumSim*(1-(handles.alpha_lvl/2)));
        %Left tail
        crit_corr_p_value_1=sorted_corr(index_corr_1,:);
        %Right tail
        crit_corr_p_value_2=sorted_corr(index_corr_2,:);
        
        %Plotting nonparametric distribution
        axes(handles.axes8);
        hs1=histfit(handles.corr_of_samp,10,'kernel');
        hold on;
        h_1=scatter(handles.corr_of_samp,repmat(handles.NumSim/100,[1,size(handles.corr_of_samp,1)]));
        delete(hs1(1));
        set(hs1(2),'Color','blue');
        set(hs1(2),'LineWidth',0.5)
        set(h_1,'MarkerEdgeColor','black');
        set(h_1,'Marker','.');
        hold on;
        h2=line([handles.stat(k,1) handles.stat(k,1)], [ylim]);
        h3=line([crit_corr_p_value_1 crit_corr_p_value_1],[ylim]);
        h4=line([crit_corr_p_value_2 crit_corr_p_value_2],[ylim]);
        set(h2,'Color','red');
        set(h3,'Color','green');
        set(h4,'Color','green');
        xlabel('\rho');
        ylabel('Frequency');
        legend([h2 h3],{'Model Value','Crit. Value'},'FontSize',8);
        box off;
        
        %Displaying p-value
        set(handles.text17,'Visible','On');
        set(handles.text17,'String',['p-value:' num2str(corr_p_value) ]);     
        
        %Preparing table
        handles.corr_data{1}=sprintf('%.3f',handles.stat(k,1));
        handles.corr_data{2}=corr_p_value;
        handles.corr_data{3}=strcat('(',num2str(sprintf('%.2f',crit_corr_p_value_1)),',',num2str(sprintf('%.2f',crit_corr_p_value_2)),')');
        handles.corr_data{4}=((handles.stat(k,1)-crit_corr_p_value_2)/(1-crit_corr_p_value_2))*100;
        
        %Assigning table values
        %set(handles.text9,'String',['The Pearson''s Correlation is ',num2str(sprintf('%.2f',handles.stat(k,1))), ' with a p-value of ', num2str(corr_p_value),' .']);
        k=k+1;
        handles.stat(k,1)=corr_p_value;
        k=k+1;
        handles.stat(k,1)=crit_corr_p_value_2;
        k=k+1;
        handles.stat(k,1)=handles.corr_data{4};
        k=k+1;
    end;

    %Activated if Nash-Sutcliffe Efficiency is chosen
    if handles.choice2==1;
        %Calculate Nash-Stucliffe Efficiency of model to observed
        handles.stat(k,1)=nash_sutcliffe(handles.Data(:,5),handles.Data(:,4));
        %Calculate p-value of nonparametric distribution through
        %enumeration
        nse_diff=abs(mean(handles.NSE_of_samp)-handles.stat(k,1));
        nse_p_value=(sum(handles.NSE_of_samp<(mean(handles.NSE_of_samp)-nse_diff))+sum(handles.NSE_of_samp>(mean(handles.NSE_of_samp)+nse_diff)))/handles.NumSim;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution
        sorted_nse=sort(handles.NSE_of_samp);
        index_nse_1=ceil(handles.NumSim*(handles.alpha_lvl/2));
        index_nse_2=ceil(handles.NumSim*(1-(handles.alpha_lvl/2)));
        %Left tail
        crit_nse_p_value_1=sorted_nse(index_nse_1,:);
        %Right tail
        crit_nse_p_value_2=sorted_nse(index_nse_2,:);
        
        %Plotting nonparametric distribution
        axes(handles.axes5);
        hs2=histfit(handles.NSE_of_samp,10,'kernel');
        hold on;
        h_2=scatter(handles.NSE_of_samp,repmat(handles.NumSim/100,[1,size(handles.NSE_of_samp,1)]));
        delete(hs2(1));
        set(hs2(2),'Color','blue');
        set(hs2(2),'LineWidth',0.5)
        set(h_2,'MarkerEdgeColor','black');
        set(h_2,'Marker','.');
        hold on;
        h2=line([handles.stat(k,1) handles.stat(k,1)], [ylim]);
        h3=line([crit_nse_p_value_1 crit_nse_p_value_1],[ylim]);
        h4=line([crit_nse_p_value_2 crit_nse_p_value_2],[ylim]);
        set(h2,'Color','red');
        set(h3,'Color','green');
        set(h4,'Color','green');
        xlabel('NSE');
        ylabel('Frequency');
        legend([h2 h3],{'Model Value','Crit. Value'},'FontSize',8);
        box off;
        
        %Displaying p-value
        set(handles.text16,'Visible','On');
        set(handles.text16,'String',['p-value:' num2str(nse_p_value) ]);
        
        %Preparing table 
        handles.nse_data{1}=sprintf('%.3f',handles.stat(k,1));
        handles.nse_data{2}=nse_p_value;
        handles.nse_data{3}=strcat('(',num2str(sprintf('%.2f',crit_nse_p_value_1)),',',num2str(sprintf('%.2f',crit_nse_p_value_2)),')');
        handles.nse_data{4}=((handles.stat(k,1)-crit_nse_p_value_2)/(1-crit_nse_p_value_2))*100;
        
        %Assinging table values
        %set(handles.text12,'String',['The Nash-Sutcliffe Efficiency is ',num2str(sprintf('%.2f',handles.stat(k,1))), ' with a p-value of ', num2str(nse_p_value),' .']);
        k=k+1;
        handles.stat(k,1)=nse_p_value;
        k=k+1;
    end
% 
    %Activated if Index of Agreement is chosen
    if handles.choice3==1;
        %Calculate Index of Agreement of model to observed
        handles.stat(k,1)=index_of_agree(handles.Data(:,5),handles.Data(:,4));       
        %Calculate p-value of nonparametric distribution through
        %enumeration        
        ioa_diff=abs(mean(handles.ioa_of_samp)-handles.stat(k,1));
        ioa_p_value=(sum(handles.ioa_of_samp<(mean(handles.ioa_of_samp)-ioa_diff))+sum(handles.ioa_of_samp>(mean(handles.ioa_of_samp)+ioa_diff)))/handles.NumSim;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution
        sorted_ioa=sort(handles.ioa_of_samp);
        index_ioa_1=ceil(handles.NumSim*(handles.alpha_lvl/2));
        index_ioa_2=ceil(handles.NumSim*(1-(handles.alpha_lvl/2)));
        %Left tail
        crit_ioa_p_value_1=sorted_ioa(index_ioa_1,:);
        %Right tail
        crit_ioa_p_value_2=sorted_ioa(index_ioa_2,:);              
   
        axes(handles.axes7);
        hs3=histfit(handles.ioa_of_samp,10,'kernel');
        hold on;
        h_3=scatter(handles.ioa_of_samp,repmat(handles.NumSim/100,[1,size(handles.ioa_of_samp,1)]));
        delete(hs3(1));
        set(hs3(2),'Color','blue');
        set(hs3(2),'LineWidth',0.5)
        set(h_3,'MarkerEdgeColor','black');
        set(h_3,'Marker','.');
        hold on;
        h2=line([handles.stat(k,1) handles.stat(k,1)], [ylim]);
        h3=line([crit_ioa_p_value_1 crit_ioa_p_value_1],[ylim]);
        h4=line([crit_ioa_p_value_2 crit_ioa_p_value_2],[ylim]);
        set(h2,'Color','red');
        set(h3,'Color','green');
        set(h4,'Color','green');
        xlabel('IOA');
        ylabel('Frequency');
        legend([h2 h3],{'Model Value','Crit. Value'},'FontSize',8);
        box off;
        
        %Displaying p-value
        set(handles.text18,'Visible','On');
        set(handles.text18,'String',['p-value:' num2str(ioa_p_value) ]);
        
        %Preparing table
        handles.ioa_data{1}=sprintf('%.3f',handles.stat(k,1));
        handles.ioa_data{2}=ioa_p_value;
        handles.ioa_data{3}=strcat('(',num2str(sprintf('%.2f',crit_ioa_p_value_1)),',',num2str(sprintf('%.2f',crit_ioa_p_value_2)),')');
        handles.ioa_data{4}=((handles.stat(k,1)-crit_ioa_p_value_2)/(1-crit_ioa_p_value_2))*100;
        
        %Assigning table values
        %set(handles.text13,'String',['The Log-Likelihood ',num2str(sprintf('%.2f',handles.stat(k,1))), ' with a p-value of ', num2str(loglike_p_value),' .']);
        k=k+1;
        handles.stat(k,1)=ioa_p_value;
        k=k+1;
    end;
        
        
%,'ColumnFormat',{'char','numeric','numeric'}
set(handles.uitable4,'Data',[handles.result_row_names handles.corr_data' handles.nse_data' handles.ioa_data']);
   
        

        set(handles.checkbox6,'Enable','on');
guidata(hObject,handles);

%%
%%%%%MODEL COMPARISON%%%%%%%

function pushbutton15_Callback(hObject, eventdata, handles)
    %Re-set tables
    set(handles.uitable3, 'Data', cell(size(get(handles.uitable3,'Data'))),'ColumnName',[],'RowName',[]);
    set(handles.uitable2, 'Data', cell(size(get(handles.uitable2,'Data'))),'ColumnName',[],'RowName',[]);
    clearvars row_names;
    clearvars handles.stat_m;
    
    
    %Load Model 2 from Excel
if handles.load_comp_choice==1;
    [handles.data3 handles.headers3]=xlsread(strcat(handles.PathName_comp,handles.FileName_comp),handles.SheetName_comp);
end;
    %Load Model 2 from CSV.
if handles.load_comp_choice==0;
    H=readtable(strcat(handles.PathName_comp_csv,handles.FileName_comp_csv));
    handles.data3=H{:,1:4};
    handles.headers3=H.Properties.VariableNames(1:4);
    handles.Units=H.Properties.VariableNames{5};
end;

       
    %Removes NaN rows
    handles.data3=handles.data3(~any(isnan(handles.data3),2),:);
    
    [C3,iA3,iB3]=intersect(handles.Data(:,1:3),handles.data3(:,1:3),'rows');
    
    %Log Transform
if handles.log_choice==1;
    handles.Data2=[handles.Data(iA3,:) log(handles.data3(iB3,4))];
end;
    %Box Cox Transform
if handles.box_choice==1;
   [transdat3]=boxcox(handles.data3(iB3,4));
   handles.Data2=[ handles.Data(iA3,:) transdat3];
end;
    %No Transform
if handles.log_choice==0 & handles.box_choice==0;
    handles.Data2=[handles.Data(iA3,:) handles.data3(iB3,4)];
end;
    
    %Add Model 2 to Data Table and time series plot
    set(handles.uitable2,'data',handles.Data2,'ColumnName',[handles.headers1(1,1:4) handles.headers2(1,4) handles.headers3(1,4)],'RowName',[num2cell(1:1:size(handles.Data(:,1),1))]);
    axes(handles.axes6);
    x=1:1:size(handles.Data2(:,1),1);
    hold on;
    m2=plot(x,handles.Data2(:,6));
    set(m2,'Color','green');
    legend([handles.headers1(1,4) handles.headers2(1,4) handles.headers3(1,4)]);
    guidata(hObject,handles);
    
    
    
%Define length
l=size(handles.Data2(:,6),1);


%handles.NumSim=number of iterations

%Loading bar
w = waitbar(0,'Running Simulation #: 0','Name','Loading Simulations...Please Wait.','CreateCancelBtn','setappdata(gcf,''canceling'',1)');
setappdata(w,'canceling',0)

for i=1:1:handles.NumSim;
    
%Method: Assign uniform probability for each entry of model length "l", then convert to
%an index ranging from 1 to "l", rounding allows for with replacement.
%Resample from Model 2, NumSim times creating vectors of length "l".

    %Exit if cancel button is pushed
    if getappdata(w,'canceling')
        break
    end
    
    %Update loading bar each simulation
    waitbar(i/handles.NumSim,w,sprintf('Running Simulation #: %i',i));
    
        %Bootstrap sample
        %handles.Data2(I,6) is the model
        boots=unifrnd(0,1,[l 1]);
        I=round(1+boots.*(l-1));
        bootsamp(:,1)=handles.Data2(I,6);


    %Calculate statistics   
    %Caclulate mean
    handles.mean_of_samp(i,1)=mean(bootsamp);
    %Calculate pearson's correlation
    handles.corr_of_samp(i,1)=corr(bootsamp(:,1),handles.Data2(1:1:l,4));
    %Calculate nash-sutcliffe efficiency
    %Using function: nash_sutcliffe( modelled,observed)
    handles.NSE_of_samp(i,1)=nash_sutcliffe(bootsamp(:,1),handles.Data2(1:1:l,4));
    %Calculate nash-sutcliffe efficiency in log space
    %Using function: log_nash_sutcliffe( modelled,observed)    
    handles.NSE_log_of_samp(i,1)=log_nash_sutcliffe(bootsamp(:,1),handles.Data2(1:1:l,4));
    %Calculate index of agreement 
    %Using function: index_of_agree(modelled, observed)
    handles.ioa_of_samp(i,1)=index_of_agree(bootsamp(:,1),handles.Data2(1:1:l,4));            

end

%delete loading bar
delete(w);

%Populate model comparison table 
k=1;
    %Activated if Pearson's Correlation is chosen
    if handles.choice1==1;
        %Calculate Pearson's Correlation of model to observed
        handles.stat_m(k,1)=corr(handles.Data2(:,6),handles.Data2(:,4));        
        %Calculate p-value of nonparametric distribution through
        %enumeration
        corr_diff=abs(mean(handles.corr_of_samp)-handles.stat_m(k,1));
        corr_p_value=(sum(handles.corr_of_samp<(mean(handles.corr_of_samp)-corr_diff))+sum(handles.corr_of_samp>(mean(handles.corr_of_samp)+corr_diff)))/handles.NumSim;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution
        sorted_corr=sort(handles.corr_of_samp);
        index_corr_1=ceil(handles.NumSim*(handles.alpha_lvl/2));
        index_corr_2=ceil(handles.NumSim*(1-(handles.alpha_lvl/2)));
        %Left tail
        crit_corr_p_value_1=sorted_corr(index_corr_1,:);
        %Right tail
        crit_corr_p_value_2=sorted_corr(index_corr_2,:);
        
        %Populating model comparison table
        row_names{k}='rho';
        k=k+1;
        row_names{k}='rho p-value';
        handles.stat_m(k,1)=corr_p_value;
        k=k+1;
        row_names{k}='crit value';
        handles.stat_m(k,1)=crit_corr_p_value_2;
        k=k+1;
        %Skill score
        row_names{k}='SS';
        handles.stat_m(k,1)=((handles.stat(k-3,1)-crit_corr_p_value_2)/(1-crit_corr_p_value_2))*100;
        k=k+1;
    end;
    
    %Activated if Nash-Sutcliffe Efficiency is chosen
    if handles.choice2==1;
        %Calculate Nash-Stucliffe Efficiency of model to observed
        handles.stat_m(k,1)=nash_sutcliffe(handles.Data2(:,6),handles.Data2(:,4));
        %Calculate p-value of nonparametric distribution through
        %enumeration
        nse_diff=abs(mean(handles.NSE_of_samp)-handles.stat_m(k,1));
        nse_p_value=(sum(handles.NSE_of_samp<(mean(handles.NSE_of_samp)-nse_diff))+sum(handles.NSE_of_samp>(mean(handles.NSE_of_samp)+nse_diff)))/handles.NumSim;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution
        sorted_nse=sort(handles.NSE_of_samp);
        index_nse_1=ceil(handles.NumSim*(handles.alpha_lvl/2));
        index_nse_2=ceil(handles.NumSim*(1-(handles.alpha_lvl/2)));
        %Left tail
        crit_nse_p_value_1=sorted_nse(index_nse_1,:);
        %Right tail
        crit_nse_p_value_2=sorted_nse(index_nse_2,:);

        %Populating model comparison table        
        row_names{k}='NSE';
        k=k+1;
        row_names{k}='NSE p-value';
        handles.stat_m(k,1)=nse_p_value;
        k=k+1;
    end
    
    %Activated if Index of Agreement is chosen
    if handles.choice3==1;
        %Calculate Index of Agreement of model to observed
        handles.stat_m(k,1)=index_of_agree(handles.Data2(:,6),handles.Data2(:,4));       
        %Calculate p-value of nonparametric distribution through
        %enumeration        
        ioa_diff=abs(mean(handles.ioa_of_samp)-handles.stat_m(k,1));
        ioa_p_value=(sum(handles.ioa_of_samp<(mean(handles.ioa_of_samp)-ioa_diff))+sum(handles.ioa_of_samp>(mean(handles.ioa_of_samp)+ioa_diff)))/handles.NumSim;
        %Calculate critical p-values of a two-tailed nonparametric
        %distribution
        sorted_ioa=sort(handles.ioa_of_samp);
        index_ioa_1=ceil(handles.NumSim*(handles.alpha_lvl/2));
        index_ioa_2=ceil(handles.NumSim*(1-(handles.alpha_lvl/2)));
        %Left tail
        crit_ioa_p_value_1=sorted_ioa(index_ioa_1,:);
        %Right tail
        crit_ioa_p_value_2=sorted_ioa(index_ioa_2,:);    
        
        %Populating model comparison table         
        row_names{k}='I.O.A.';
        k=k+1;
        row_names{k}='I.O.A. p-value';
        handles.stat_m(k,1)=ioa_p_value;
        k=k+1;
    end;
    
    %Calculate model comparison stats: AIC and BIC
        handles.rss1=sum((handles.Data2(:,4)-handles.Data2(:,5)).^2);
        handles.rss2=sum((handles.Data2(:,4)-handles.Data2(:,6)).^2);
    
        row_names{k}='AIC';
    
        aic1=l+(l*log(2*pi))+(l*log(handles.rss1/l))+(2*(handles.mod1_parm_num+1));
        aic2=l+(l*log(2*pi))+(l*log(handles.rss2/l))+(2*(handles.mod2_parm_num+1));
        
        handles.stat(k,1)=aic1;
        handles.stat_m(k,1)=aic2;

        k=k+1;
        row_names{k}='BIC';
        
        bic1=l+(l*log(2*pi))+(l*log(handles.rss1/l))+(log(l)*(handles.mod1_parm_num+1));
        bic2=l+(l*log(2*pi))+(l*log(handles.rss2/l))+(log(l)*(handles.mod2_parm_num+1));
        
        handles.stat(k,1)=bic1;
        handles.stat_m(k,1)=bic2;
        stat_data=[handles.stat(:,1) handles.stat_m(:,1)];
        %,'ColumnFormat',{'char','numeric','numeric'}
        set(handles.uitable3,'Data',[row_names' num2cell(stat_data)],'ColumnName',['Stat' handles.headers2(1,4) handles.headers3(1,4)]);
        
guidata(hObject,handles);
%%

function edit4_Callback(hObject, eventdata, handles)
    SheetName_obs=get(hObject,'String');
    handles.SheetName_obs=SheetName_obs;
    guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
    [FileName_obs_csv,PathName_obs_csv] = uigetfile('*.csv','Select the Comma Delimited File',pwd);
    handles.FileName_obs=FileName_obs_csv;
    handles.PathName_obs=PathName_obs_csv;
    guidata(hObject,handles);


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
    [FileName_obs_ex,PathName_obs_ex] = uigetfile('*.xlsx','Select the Excel Workbook','C:/Users/dalibera/Documents/Research/NSE Toolkit/');
    handles.FileName_obs=FileName_obs_ex;
    handles.PathName_obs=PathName_obs_ex;
    guidata(hObject,handles);

% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
    [FileName_mod_csv,PathName_mod_csv] = uigetfile('*.csv','Select the Comma Delimited File',pwd);
    handles.FileName_mod=FileName_mod_csv;
    handles.PathName_mod=PathName_mod_csv;
    guidata(hObject,handles);
    
    
% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
    [FileName_mod_ex,PathName_mod_ex] = uigetfile('*.xlsx','Select the Excel Workbook','C:/Users/dalibera/Documents/Research/NSE Toolkit/');
    handles.FileName_mod=FileName_mod_ex;
    handles.PathName_mod=PathName_mod_ex;
    guidata(hObject,handles);



function edit5_Callback(hObject, eventdata, handles)
    SheetName_mod=get(hObject,'String');
    handles.SheetName_mod=SheetName_mod;
    guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in radiobutton9.
function radiobutton9_Callback(hObject, eventdata, handles)
 if get(hObject,'Value')==1;
     handles.load_obs_choice=1;
     set(handles.pushbutton9,'Enable','on');
     set(handles.edit4,'Enable','on');
     set(handles.pushbutton8,'Enable','off');
 end;
    guidata(hObject,handles);


% --- Executes on button press in radiobutton10.
function radiobutton10_Callback(hObject, eventdata, handles)
if get(hObject,'Value')==1;
     handles.load_obs_choice=0;
     set(handles.pushbutton8,'Enable','on');
     set(handles.pushbutton9,'Enable','off');
     set(handles.edit4,'Enable','off');
end;
    guidata(hObject,handles);


% --- Executes on button press in radiobutton12.
function radiobutton12_Callback(hObject, eventdata, handles)
if get(hObject,'Value')==1;
     handles.load_mod_choice=1;
     set(handles.pushbutton11,'Enable','on');
     set(handles.edit5,'Enable','on');
     set(handles.pushbutton10,'Enable','off');
end
    guidata(hObject,handles);


% --- Executes on button press in radiobutton11.
function radiobutton11_Callback(hObject, eventdata, handles)
if get(hObject,'Value')==1;
     handles.load_mod_choice=0;
     set(handles.pushbutton10,'Enable','on');
     set(handles.pushbutton11,'Enable','off');
     set(handles.edit5,'Enable','off');
end
    guidata(hObject,handles);

% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
    handles.log_choice=get(hObject,'Value');
    if handles.log_choice==1;
    set(handles.checkbox5,'Enable','off');
    else
    set(handles.checkbox5,'Enable','on');
    end;
    guidata(hObject,handles);


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
    if get(hObject,'Value')==1;
        handles.choice1=1;
    end;
    if get(hObject,'Value')==0;
        handles.choice1=0;
    end;
    guidata(hObject,handles);

% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
    if get(hObject,'Value')==1;
        handles.choice2=1;
    end;
    if get(hObject,'Value')==0;
        handles.choice2=0;
    end;
    guidata(hObject,handles);

% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
     if get(hObject,'Value')==1;
        handles.choice3=1;
    end;
    if get(hObject,'Value')==0;
        handles.choice3=0;
    end;
    guidata(hObject,handles);


function edit7_Callback(hObject, eventdata, handles)
    handles.NumSim=str2num(get(hObject,'String'));
    guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox5.
function checkbox5_Callback(hObject, eventdata, handles)
    handles.box_choice=get(hObject,'Value');
    if handles.box_choice==1;
    set(handles.checkbox1,'Enable','off');
    else
    set(handles.checkbox1,'Enable','on');
    end;
    guidata(hObject,handles);



function edit8_Callback(hObject, eventdata, handles)

    handles.lambda=get(hObject,'Value');
    guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
    handles.SheetName_comp=get(hObject,'String');    
    guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
    [FileName_comp_csv,PathName_comp_csv] = uigetfile('*.csv','Select the Comma Delimited File',pwd);
    handles.FileName_obs=FileName_comp_csv;
    handles.PathName_obs=PathName_comp_csv;
    guidata(hObject,handles);

% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
    [FileName_comp_ex,PathName_comp_ex] = uigetfile('*.xlsx','Select the Excel Workbook','C:/Users/dalibera/Documents/Research/NSE Toolkit/');
    handles.FileName_comp=FileName_comp_ex;
    handles.PathName_comp=PathName_comp_ex;
    guidata(hObject,handles);

% --- Executes on button press in checkbox6.
function checkbox6_Callback(hObject, eventdata, handles)
    if get(hObject,'Value')==0;
        set(handles.radiobutton19,'Enable','off');
        set(handles.radiobutton20,'Enable','off');
        set(handles.pushbutton13,'Enable','off');
        set(handles.pushbutton14,'Enable','off');
        set(handles.pushbutton15,'Enable','off');
        set(handles.text20,'Enable','off');
        set(handles.edit9,'Enable','off');
        set(handles.uitable3,'Enable','off');
        set(handles.text21,'Enable','off');
        set(handles.text22,'Enable','off');
        set(handles.edit10,'Enable','off');
        set(handles.edit11,'Enable','off');
    end;
    if get(hObject,'Value')==1;
        set(handles.radiobutton19,'Enable','on');
        set(handles.radiobutton20,'Enable','on');
        set(handles.pushbutton15,'Enable','on');
        set(handles.pushbutton14,'Enable','on');
        set(handles.text20,'Enable','on');
        set(handles.edit9,'Enable','on');
        set(handles.uitable3,'Enable','on');
        set(handles.text21,'Enable','on');
        set(handles.text22,'Enable','on');
        set(handles.edit10,'Enable','on');
        set(handles.edit11,'Enable','on');
    end;
    guidata(hObject,handles);


% --- Executes on button press in radiobutton19.
function radiobutton19_Callback(hObject, eventdata, handles)
    if get(hObject,'Value')==1 & get(handles.checkbox6,'Value')==1;
       set(handles.pushbutton14,'Enable','on');
       set(handles.text20,'Enable','on');
       set(handles.edit9,'Enable','on');
       set(handles.pushbutton13,'Enable','off');
    end;
    if get(hObject,'Value')==0 & get(handles.checkbox6,'Value')==1;
       set(handles.pushbutton14,'Enable','off');
       set(handles.text20,'Enable','off');
       set(handles.edit9,'Enable','off');
       set(handles.pushbutton13,'Enable','on');
       
    end;
    guidata(hObject,handles);


% --- Executes on button press in radiobutton20.
function radiobutton20_Callback(hObject, eventdata, handles)
    if get(hObject,'Value')==1 & get(handles.checkbox6,'Value')==1;
        set(handles.pushbutton13,'Enable','on');
        set(handles.pushbutton14,'Enable','off');
        set(handles.text20,'Enable','off');
        set(handles.edit9,'Enable','off');        
    end;
    if get(hObject,'Value')==0 & get(handles.checkbox6,'Value')==1;
        set(handles.pushbutton13,'Enable','off');
        set(handles.pushbutton14,'Enable','on');
        set(handles.text20,'Enable','on');
        set(handles.edit9,'Enable','on');        
    end;
    guidata(hObject,handles);




function edit10_Callback(hObject, eventdata, handles)
    handles.mod1_parm_num=get(hObject,'Value');
    guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
    handles.mod2_parm_num=get(hObject,'Value');
    guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)

        xlswrite('toolkit_output.xlsx',[get(handles.uitable3,'ColumnName')';get(handles.uitable3,'Data')],'Sheet1');
        xlswrite('toolkit_output.xlsx',[get(handles.uitable2,'ColumnName')';num2cell(get(handles.uitable2,'Data'))],'Sheet2');

        export_fig(handles.axes6,'time_series.jpeg','-m2.5');
    if handles.choice1==1;
        export_fig(handles.axes8,'pearsons.jpeg','-m2.5');
    end
    if handles.choice2==1;
        export_fig(handles.axes5,'nash_sutcliffe.jpeg','-m2.5');
    end
    if handles.choice3==1;
        export_fig(handles.axes7,'log_likelihood','-m2.5');
    end
    guidata(hObject,handles);


% --- Executes on button press in radiobutton24.
function radiobutton24_Callback(hObject, eventdata, handles)
        if get(hObject,'Value')==1;
              handles.homo_error=1;
        end;
        if get(hObject,'Value')==0;
              handles.homo_error=0;
        end;
 guidata(hObject,handles);


% --- Executes on button press in radiobutton25.
function radiobutton25_Callback(hObject, eventdata, handles)
        if get(hObject,'Value')==1;
              handles.hetero_error=1;
        end;
        if get(hObject,'Value')==0;
              handles.hetero_error=0;
        end;
 guidata(hObject,handles);
