function [ nse ] = log_nash_sutcliffe( modelled,observed)
%Nash Sutcliffe Efficiency measure

log_model=log(modelled);
log_obs=log(observed);


diff=log_model-log_obs; %start after warmup period
diffmeanflow=log_obs-(mean(log_obs)); 
nse= 1-(sum(diff.^2))/(sum(diffmeanflow.^2));

end
